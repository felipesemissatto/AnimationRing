//
//  InterfaceController.swift
//  AnimationRing WatchKit Extension
//
//  Created by Felipe Semissatto on 29/06/20.
//  Copyright © 2020 Felipe Semissatto. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    //MARK: -Outlets
    @IBOutlet weak var groupRing: WKInterfaceGroup!
    
    //MARK: -IBActions
    @IBAction func startAnimationRing() {
        // 1
        let range = NSRange(location: 0, length: 101)
        // 2
        let duration = 1.0
        // 3
        let repeatCount = 1
        
        // 4
        self.groupRing.setBackgroundImageNamed("ring")
        
        // 5
        self.groupRing.startAnimatingWithImages(in: range,
                                                duration: duration,
                                                repeatCount: repeatCount)
    }
}
